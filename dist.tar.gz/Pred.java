import java.util.Map;

public abstract class Pred {
	public abstract boolean eval(int[] row,Map<String,Integer> rowN);
}
